<?php

$mod_strings['LBL_CONVERT_LEAD_C'] = 'Convert Lead';
